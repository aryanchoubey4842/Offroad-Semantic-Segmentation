import os
import cv2
import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm
from transformers import SegformerForSemanticSegmentation
import albumentations as A
from albumentations.pytorch import ToTensorV2

# ==================================================
# CONFIG
# ==================================================
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

NUM_CLASSES = 10
IMG_SIZE = 512

MODEL_NAME = "nvidia/segformer-b4-finetuned-ade-512-512"
MODEL_PATH = "best_model.pth"

TEST_DIR = "predictions/Color_Images"

SAVE_MASK_DIR = "predictions/output_masks"
SAVE_VIS_DIR = "predictions/output_visual"

os.makedirs(SAVE_MASK_DIR, exist_ok=True)
os.makedirs(SAVE_VIS_DIR, exist_ok=True)

# ==================================================
# COLOR MAP
# ==================================================
COLORS = np.array([
    [0,0,0],[255,0,0],[0,255,0],[0,0,255],
    [255,255,0],[255,0,255],[0,255,255],
    [128,128,0],[128,0,128],[0,128,128]
], dtype=np.uint8)

# ==================================================
# PREPROCESS
# ==================================================
transform = A.Compose([
    A.Resize(IMG_SIZE, IMG_SIZE),
    A.Normalize(),
    ToTensorV2()
])

# ==================================================
# MODEL
# ==================================================
model = SegformerForSemanticSegmentation.from_pretrained(
    MODEL_NAME,
    num_labels=NUM_CLASSES,
    ignore_mismatched_sizes=True
).to(DEVICE)

model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
model.eval()

print("✅ Model loaded")

# ==================================================
# MULTISCALE + TTA PREDICTION
# ==================================================
def predict_image(image):

    h, w = image.shape[:2]

    aug = transform(image=image)
    x = aug["image"].unsqueeze(0).to(DEVICE)

    scales = [0.75, 1.0, 1.25]

    final_pred = 0

    with torch.no_grad():

        for s in scales:

            scaled = F.interpolate(
                x, scale_factor=s,
                mode="bilinear",
                align_corners=False
            )

            # ----- normal -----
            p1 = model(pixel_values=scaled).logits

            # ----- horizontal flip TTA -----
            flipped = torch.flip(scaled, dims=[3])
            p2 = model(pixel_values=flipped).logits
            p2 = torch.flip(p2, dims=[3])

            pred = (p1 + p2) / 2

            pred = F.interpolate(
                pred,
                size=(IMG_SIZE, IMG_SIZE),
                mode="bilinear",
                align_corners=False
            )

            final_pred += pred

    final_pred /= len(scales)

    # resize back
    final_pred = F.interpolate(
        final_pred,
        size=(h, w),
        mode="bilinear",
        align_corners=False
    )

    mask = final_pred.argmax(1).squeeze().cpu().numpy().astype(np.uint8)

    # ---- optional smoothing ----
    kernel = np.ones((3,3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

    return mask

# ==================================================
# INFERENCE LOOP
# ==================================================
images = sorted(os.listdir(TEST_DIR))

for name in tqdm(images):

    img_path = os.path.join(TEST_DIR, name)
    img = cv2.imread(img_path)

    if img is None:
        continue

    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    mask = predict_image(rgb)

    # save raw mask
    cv2.imwrite(os.path.join(SAVE_MASK_DIR, name), mask)

    # visualization
    color_mask = COLORS[mask]
    overlay = cv2.addWeighted(rgb, 0.6, color_mask, 0.4, 0)

    cv2.imwrite(
        os.path.join(SAVE_VIS_DIR, name),
        cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    )

print("🎯 PRO inference complete!")
