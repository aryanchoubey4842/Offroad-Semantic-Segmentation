import torch
import torch.nn as nn
import torch.nn.functional as F

class DiceLoss(nn.Module):
    def __init__(
        self,
        num_classes=10,
        smooth=1.0,
        ignore_index=None,
        include_background=False
    ):
        super().__init__()

        self.num_classes = num_classes
        self.smooth = smooth
        self.ignore_index = ignore_index
        self.include_background = include_background

    def forward(self, logits, targets):

        # probabilities
        probs = torch.softmax(logits, dim=1)

        # one-hot targets
        targets_onehot = F.one_hot(
            targets,
            num_classes=self.num_classes
        ).permute(0,3,1,2).float()

        # optional ignore index
        if self.ignore_index is not None:
            mask = (targets != self.ignore_index).unsqueeze(1)
            probs = probs * mask
            targets_onehot = targets_onehot * mask

        # ----- per-class dice -----
        intersection = (probs * targets_onehot).sum(dim=(2,3))
        union = probs.sum(dim=(2,3)) + targets_onehot.sum(dim=(2,3))

        dice = (2 * intersection + self.smooth) / (
            union + self.smooth + 1e-7
        )

        # ⭐ optional: ignore background class
        if not self.include_background:
            dice = dice[:, 1:]   # remove class 0

        return 1 - dice.mean()
