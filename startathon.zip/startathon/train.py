import os
import cv2
import random
import numpy as np
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from transformers import SegformerForSemanticSegmentation

import albumentations as A
from albumentations.pytorch import ToTensorV2
from tqdm import tqdm

# ==================================================
# SETTINGS
# ==================================================
torch.backends.cudnn.benchmark = True
torch.set_float32_matmul_precision("high")

SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

DEVICE = "cuda"
NUM_CLASSES = 10

BATCH_SIZE = 2
ACCUM_STEPS = 2
EPOCHS = 12
LR = 6e-5
IMG_SIZE = 512

TRAIN_IMG_DIR = "data/train/Color_Images"
TRAIN_MASK_DIR = "data/train/Segmentation"
VAL_IMG_DIR = "data/val/Color_Images"
VAL_MASK_DIR = "data/val/Segmentation"

# ==================================================
# CLASS MAP
# ==================================================
ID_MAP = {
    100:0, 200:1, 300:2, 500:3, 550:4,
    600:5, 700:6, 800:7, 7100:8, 10000:9
}

def remap_mask(mask):
    new = np.zeros_like(mask, dtype=np.uint8)
    for k,v in ID_MAP.items():
        new[mask == k] = v
    return new

# ==================================================
# AUGMENTATIONS
# ==================================================
train_tf = A.Compose([
    A.RandomResizedCrop(size=(IMG_SIZE, IMG_SIZE), scale=(0.55,1.0), ratio=(0.75,1.33)),
    A.HorizontalFlip(p=0.5),
    A.RandomBrightnessContrast(p=0.5),
    A.HueSaturationValue(p=0.4),
    A.GaussianBlur(p=0.2),
    A.Normalize(),
    ToTensorV2()
])

val_tf = A.Compose([
    A.Resize(IMG_SIZE, IMG_SIZE),
    A.Normalize(),
    ToTensorV2()
])

# ==================================================
# DATASET
# ==================================================
class DesertDataset(Dataset):
    def __init__(self,img_dir,mask_dir,transform):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.images = sorted(os.listdir(img_dir))
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self,idx):
        name = self.images[idx]

        img = cv2.cvtColor(
            cv2.imread(os.path.join(self.img_dir,name)),
            cv2.COLOR_BGR2RGB
        )

        mask = cv2.imread(
            os.path.join(self.mask_dir,name),
            cv2.IMREAD_UNCHANGED
        )

        mask = remap_mask(mask)

        aug = self.transform(image=img, mask=mask)

        return aug["image"], aug["mask"].long()

# ==================================================
# LOSS
# ==================================================
class DiceLoss(nn.Module):
    def forward(self, logits, targets):
        probs = torch.softmax(logits, dim=1)
        onehot = F.one_hot(targets, NUM_CLASSES).permute(0,3,1,2).float()

        inter = (probs * onehot).sum((2,3))
        union = probs.sum((2,3)) + onehot.sum((2,3))

        dice = (2*inter + 1)/(union + 1)
        return 1 - dice.mean()

# ==================================================
# METRICS
# ==================================================
def pixel_accuracy(pred, mask):
    pred = pred.argmax(1)
    return (pred == mask).float().mean().item()

def compute_iou(pred, mask):
    pred = pred.argmax(1)
    ious = []

    for c in range(NUM_CLASSES):
        p = (pred == c)
        m = (mask == c)

        inter = (p & m).sum().item()
        union = (p | m).sum().item()

        if union > 0:
            ious.append(inter / union)

    return np.mean(ious)

# ⭐ SEGMENTATION mAP@50
def compute_map50(pred, mask):
    pred = pred.argmax(1)

    aps = []

    for c in range(NUM_CLASSES):
        p = (pred == c)
        m = (mask == c)

        inter = (p & m).sum().item()
        union = (p | m).sum().item()

        if union == 0:
            continue

        iou = inter / union

        # IoU threshold = 0.5
        aps.append(1.0 if iou >= 0.5 else 0.0)

    return np.mean(aps) if len(aps) else 0.0

# ==================================================
# MAIN
# ==================================================
def main():

    model = SegformerForSemanticSegmentation.from_pretrained(
        "nvidia/segformer-b4-finetuned-ade-512-512",
        num_labels=NUM_CLASSES,
        ignore_mismatched_sizes=True
    ).to(DEVICE)

    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

    ce_loss = nn.CrossEntropyLoss(label_smoothing=0.05)
    dice_loss = DiceLoss()

    scaler = torch.amp.GradScaler("cuda")

    train_loader = DataLoader(
        DesertDataset(TRAIN_IMG_DIR, TRAIN_MASK_DIR, train_tf),
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=0,   # Windows safe
        pin_memory=True
    )

    val_loader = DataLoader(
        DesertDataset(VAL_IMG_DIR, VAL_MASK_DIR, val_tf),
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        pin_memory=True
    )

    train_losses, val_ious, val_accs, val_map50 = [], [], [], []

    best_iou = 0

    for epoch in range(EPOCHS):

        model.train()
        optimizer.zero_grad()
        loop = tqdm(train_loader)

        epoch_loss = 0

        for step,(imgs,masks) in enumerate(loop):

            imgs,masks = imgs.to(DEVICE), masks.to(DEVICE)

            with torch.amp.autocast("cuda"):
                outputs = model(pixel_values=imgs).logits
                outputs = F.interpolate(outputs,size=masks.shape[-2:],mode="bilinear",align_corners=False)

                loss = ce_loss(outputs,masks) + 0.5*dice_loss(outputs,masks)
                loss = loss / ACCUM_STEPS

            scaler.scale(loss).backward()

            if (step+1)%ACCUM_STEPS==0:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

            epoch_loss += loss.item()*ACCUM_STEPS
            loop.set_postfix(loss=loss.item()*ACCUM_STEPS)

        scheduler.step()
        train_losses.append(epoch_loss/len(train_loader))

        # ===== VALIDATION =====
        model.eval()
        ious, accs, maps = [], [], []

        with torch.no_grad():
            for imgs,masks in val_loader:

                imgs,masks = imgs.to(DEVICE), masks.to(DEVICE)

                outputs = model(pixel_values=imgs).logits
                outputs = F.interpolate(outputs,size=masks.shape[-2:],mode="bilinear",align_corners=False)

                ious.append(compute_iou(outputs,masks))
                accs.append(pixel_accuracy(outputs,masks))
                maps.append(compute_map50(outputs,masks))

        mean_iou = np.mean(ious)
        mean_acc = np.mean(accs)
        mean_map50 = np.mean(maps)

        val_ious.append(mean_iou)
        val_accs.append(mean_acc)
        val_map50.append(mean_map50)

        print(
            f"Epoch {epoch+1} | IoU: {mean_iou:.4f} | "
            f"Acc: {mean_acc:.4f} | mAP50: {mean_map50:.4f}"
        )

        if mean_iou > best_iou:
            best_iou = mean_iou
            torch.save(model.state_dict(), "best_model.pth")
            print("✅ Saved Best Model")

    # ===== PLOTS =====
    plt.figure()
    plt.plot(train_losses, label="Train Loss")
    plt.legend()
    plt.savefig("loss_curve.png")

    plt.figure()
    plt.plot(val_ious, label="Val IoU")
    plt.plot(val_accs, label="Val Acc")
    plt.plot(val_map50, label="mAP50")
    plt.legend()
    plt.savefig("metrics_curve.png")

    print("📊 Graphs saved")

if __name__ == "__main__":
    main()
