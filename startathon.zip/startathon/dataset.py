import os
import cv2
import numpy as np
from torch.utils.data import Dataset
import albumentations as A
from albumentations.pytorch import ToTensorV2

# ===============================
# CONFIG
# ===============================
IMG_SIZE = 512

ID_MAP = {
    100:0, 200:1, 300:2, 500:3, 550:4,
    600:5, 700:6, 800:7, 7100:8, 10000:9
}

def remap_mask(mask):
    new = np.zeros_like(mask, dtype=np.uint8)
    for k,v in ID_MAP.items():
        new[mask == k] = v
    return new

# ===============================
# AUGMENTATIONS
# ===============================
train_tf = A.Compose([
    A.RandomResizedCrop(
        size=(IMG_SIZE, IMG_SIZE),
        scale=(0.55,1.0),
        ratio=(0.75,1.33)
    ),
    A.HorizontalFlip(p=0.5),
    A.ShiftScaleRotate(
        shift_limit=0.08,
        scale_limit=0.15,
        rotate_limit=12,
        border_mode=cv2.BORDER_REFLECT_101,
        p=0.5
    ),
    A.RandomBrightnessContrast(p=0.5),
    A.HueSaturationValue(p=0.4),
    A.CLAHE(p=0.25),
    A.RGBShift(p=0.3),

    A.OneOf([
        A.GaussianBlur(blur_limit=5),
        A.MotionBlur(blur_limit=5)
    ], p=0.25),

    A.Normalize(),
    ToTensorV2()
])

val_tf = A.Compose([
    A.Resize(IMG_SIZE, IMG_SIZE),
    A.Normalize(),
    ToTensorV2()
])

# ===============================
# DATASET
# ===============================
class DesertDataset(Dataset):

    def __init__(self, img_dir, mask_dir, transform):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.images = sorted(os.listdir(img_dir))
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):

        name = self.images[idx]

        image = cv2.cvtColor(
            cv2.imread(os.path.join(self.img_dir,name)),
            cv2.COLOR_BGR2RGB
        )

        mask = cv2.imread(
            os.path.join(self.mask_dir,name),
            cv2.IMREAD_UNCHANGED
        )

        mask = remap_mask(mask)

        aug = self.transform(image=image, mask=mask)

        return aug["image"], aug["mask"].long()
