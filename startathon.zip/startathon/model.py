from transformers import SegformerForSemanticSegmentation

# ===============================
# MODEL CONFIG
# ===============================
NUM_CLASSES = 10

# ⭐ Default model (BEST balance for you)
MODEL_NAME = "nvidia/segformer-b4-finetuned-ade-512-512"


def get_model(device="cuda", model_name=MODEL_NAME):
    """
    Load SegFormer model.

    Args:
        device: "cuda" or "cpu"
        model_name: any SegFormer variant

    Returns:
        model on target device
    """

    model = SegformerForSemanticSegmentation.from_pretrained(
        model_name,
        num_labels=NUM_CLASSES,
        ignore_mismatched_sizes=True
    )

    return model.to(device)
